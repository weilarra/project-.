OPENAI_API_KEY = ""  # or leave blank if using local model
PAPER_FOLDER = "papers"
INDEX_FOLDER = "index_storage"
MODEL_NAME = "gemma3:27b-it-qat"  # or local model name