import os
import threading
import gradio as gr

# ===================== 导入后端逻辑（需确保 test.py 与当前文件同目录） =====================
import agent_scholar_version2 as backend

# ===================== 全局变量（线程安全） =====================
# 全局索引实例（加载后复用）
INDEX = None
# 索引操作锁（避免多线程冲突）
INDEX_LOCK = threading.Lock()

# ===================== 核心工具函数 =====================
def _format_markdown(response, nodes):
    """
    将回答内容和参考来源格式化为 Markdown 字符串
    :param response: 后端返回的回答结果
    :param nodes: 检索到的文档节点列表
    :return: 格式化后的 Markdown 文本
    """
    # 提取核心回答文本（兼容 RAG/FREE 两种模式）
    if hasattr(response, "response") and isinstance(response.response, str):
        text = response.response
    elif hasattr(response, "text") and isinstance(response.text, str):
        text = response.text
    else:
        text = str(response)

    # 处理参考来源（优先级：response自带source_nodes > 传入的nodes）
    source_nodes = getattr(response, "source_nodes", None)
    if not source_nodes:
        source_nodes = nodes if isinstance(nodes, list) else []

    # 拼接参考来源信息
    if source_nodes:
        lines = ["\n\n---\n### 参考来源"]
        for sn in source_nodes:
            # 提取文件路径和相似度分数
            node = getattr(sn, "node", None)
            file_path = ""
            if node and hasattr(node, "metadata"):
                file_path = node.metadata.get("file_path", "") or node.metadata.get("filename", "")
            score = getattr(sn, "score", None)
            
            # 仅显示文件名（避免路径过长影响UI）
            base_name = os.path.basename(file_path) if file_path else "未知文件"
            if score is not None:
                lines.append(f"- {base_name} (score={score:.3f})")
            else:
                lines.append(f"- {base_name}")
        text += "\n" + "\n".join(lines)
    else:
        text += "\n\n> 本次回答未引用文档"

    return text

def _append_messages(chat_history, user_msg, assistant_msg):
    """
    追加对话记录（适配 Gradio Chatbot 默认的 messages 格式）
    :param chat_history: 历史对话列表（每项为 {"role": "...", "content": "..."}）
    :param user_msg: 用户输入的问题
    :param assistant_msg: 助手返回的回答
    :return: 更新后的对话历史
    """
    return chat_history + [
        {"role": "user", "content": user_msg},
        {"role": "assistant", "content": assistant_msg},
    ]

def load_index(papers, index_dir, base_url, llm_model, embed_model):
    """
    加载/初始化索引（线程安全，带异常处理）
    :param papers: 论文目录路径
    :param index_dir: 索引存储目录
    :param base_url: Ollama 服务地址
    :param llm_model: LLM 模型名称
    :param embed_model: Embedding 模型名称
    :return: Gradio 状态更新对象
    """
    global INDEX
    with INDEX_LOCK:
        try:
            # 覆盖后端全局配置
            backend.INDEX_FOLDER = index_dir
            backend.OLLAMA_BASE_URL = base_url
            backend.LLM_MODEL = llm_model
            backend.EMBED_MODEL = embed_model
            
            # 确保目录存在并构建/加载索引
            backend.ensure_dirs(papers)
            INDEX = backend.build_or_load_index(papers)
            return gr.update(value="✅ 状态：索引已就绪")
        except Exception as e:
            # 加载失败时返回具体错误信息，便于排查
            return gr.update(value=f"❌ 状态：索引加载失败 - {str(e)}")

def rebuild_index(papers, index_dir, base_url, llm_model, embed_model):
    """重建索引（复用加载逻辑）"""
    return load_index(papers, index_dir, base_url, llm_model, embed_model)

def respond(message, chat_history, top_k, mode):
    """
    对话核心逻辑（适配 messages 格式）：接收问题 → 调用后端 → 返回格式化结果
    :param message: 用户输入的问题
    :param chat_history: 历史对话记录（messages 格式）
    :param top_k: 检索 Top-K 数量
    :param mode: 回答模式（compact/tree_summarize等）
    :return: 清空输入框 + 更新后的对话历史
    """
    global INDEX
    # 索引未就绪时的友好提示
    if INDEX is None:
        return "", _append_messages(chat_history, message, "⚠️ 索引未就绪，请先点击「加载索引」按钮！")
    
    try:
        # 调用后端路由+回答逻辑
        response, nodes = backend.retrieve_then_answer(
            INDEX, message, top_k=int(top_k), response_mode=mode
        )
        # 格式化为 Markdown
        md_content = _format_markdown(response, nodes)
        # 更新对话历史（messages 格式）
        return "", _append_messages(chat_history, message, md_content)
    except Exception as e:
        # 异常捕获，返回详细排查指引
        error_msg = f"❌ 处理失败：{str(e)}\n建议检查：\n1. Ollama 服务是否启动（http://127.0.0.1:11434）\n2. 模型是否已下载（gemma3:27b-it-qat/nomic-embed-text）\n3. 论文目录是否有可解析文件（PDF/TXT/MD）"
        return "", _append_messages(chat_history, message, error_msg)

# ===================== UI 构建（Chatbot 不添加 type 参数） =====================
def build_ui():
    """构建Gradio界面（Chatbot 使用默认的 messages 格式，不添加 type 参数）"""
    with gr.Blocks(title="文献助手（Gradio）", fill_height=True) as demo:
        # 页面标题
        gr.Markdown("# 📚 文献助手\n与语料相关则检索并严格依文档回答；不相关则自由回答（在对话前先点击“加载索引”，首次对话需要加载LLM，需要等待大约30s）。")

        # 第一行：路径配置
        with gr.Row():
            papers = gr.Textbox(value="./papers", label="论文目录")
            index_dir = gr.Textbox(value="./index", label="索引目录")

        # 第二行：模型配置
        with gr.Row():
            base_url = gr.Textbox(value="http://localhost:11434", label="Ollama 地址")
            llm_model = gr.Textbox(value="gemma3:27b-it-qat", label="LLM 模型")
            embed_model = gr.Textbox(value="nomic-embed-text", label="Embedding 模型")

        # 第三行：索引操作按钮 + 状态提示
        with gr.Row():
            load_btn = gr.Button("加载索引", variant="primary")
            rebuild_btn = gr.Button("重建索引")
            status = gr.Markdown("📝 状态：尚未加载索引")

        # 对话区域（核心：Chatbot 不添加 type 参数，使用默认的 messages 格式）
        chatbot = gr.Chatbot(
            label="对话记录",
            height=520,
            render_markdown=True  # 仅保留核心参数，不添加 type 参数
        )

        # 第四行：用户输入框
        with gr.Row():
            msg = gr.Textbox(
                label="你的问题（回车发送）", 
                placeholder="例如：这两篇论文的创新点是什么？", 
                scale=4
            )

        # 第五行：参数配置 + 操作按钮
        with gr.Row():
            top_k = gr.Slider(1, 12, value=6, step=1, label="检索 Top-K")
            mode = gr.Dropdown(
                choices=["compact", "tree_summarize", "compact_accumulate"],
                value="compact", 
                label="回答模式"
            )
            send = gr.Button("发送", variant="primary")
            clear_btn = gr.Button("清空对话")

        # ===================== 事件绑定 =====================
        # 索引操作
        load_btn.click(load_index, [papers, index_dir, base_url, llm_model, embed_model], [status])
        rebuild_btn.click(rebuild_index, [papers, index_dir, base_url, llm_model, embed_model], [status])

        # 对话操作（适配 messages 格式）
        msg.submit(respond, [msg, chatbot, top_k, mode], [msg, chatbot])
        send.click(respond, [msg, chatbot, top_k, mode], [msg, chatbot])
        clear_btn.click(lambda: [], None, chatbot, queue=False)

        # 底部提示
        gr.Markdown("提示：与文档相关的问题会在答案下方显示“参考来源”。如未命中文档，请检查目录与索引是否正确加载。")

    return demo

# ===================== 主函数（极简启动方式） =====================
if __name__ == "__main__":
    # 构建UI（不使用queue的不兼容参数）
    demo = build_ui()
    # 启动服务（0.0.0.0 允许局域网访问，端口7860）
    demo.launch(
        server_name="0.0.0.0",
        server_port=7860,
        inbrowser=False
    )
    
    #网址地址http://127.0.0.1:7860/