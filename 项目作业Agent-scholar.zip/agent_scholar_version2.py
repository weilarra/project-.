import os
import sys
import glob
import argparse

from llama_index.core import (
    VectorStoreIndex,
    SimpleDirectoryReader,
    StorageContext,
    load_index_from_storage,
    Settings,
)
from llama_index.llms.ollama import Ollama
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.core.response_synthesizers import get_response_synthesizer
from llama_index.core.prompts import PromptTemplate

try:
    from ollama import stop as ollama_stop
except Exception:
    ollama_stop = None

# ===================== 全局配置（可被命令行覆盖） =====================
# 默认路径配置
DEFAULT_PAPER_FOLDER = "./papers"
INDEX_FOLDER = "./index"
OLLAMA_BASE_URL = "http://localhost:11434"

# 模型配置
LLM_MODEL = "gemma3:27b-it-qat"
EMBED_MODEL = "nomic-embed-text"

# 支持的文件格式
ALLOWED_EXTS = {".pdf", ".txt", ".md"}

# 运行优化选项
NUM_CTX = 4096  # 降低 KV cache 内存占用
NUM_GPU = 999   # 尽量将模型层放入显存（999=自动最大化）
LLM_KEEP_ALIVE = "10m"  # LLM保活时长（交互期内避免频繁重载）
NO_OVERLAP = True  # 检索前停止LLM，避免与嵌入模型叠加占用内存

# 全局变量：语料标题（供LLM路由参考）
CORPUS_TITLES = []

# ===================== 提示词模板 =====================
# 严格基于文档回答的QA模板（避免幻觉）
STRICT_QA_TEMPLATE = PromptTemplate(
    "你将获得若干文档片段(context)。请严格依据这些片段回答用户问题，不要使用外部知识。\n"
    "如果文档片段不足以回答，请直接回复：'我在提供的文档中没有找到相关内容。'\n"
    "请使用用户问题的语种作答。\n\n"
    "用户问题：{query_str}\n"
    "文档片段：\n{context_str}\n"
)


# ===================== 工具函数 =====================
def find_files(root_dir):
    """递归查找指定目录下的合法文件（PDF/TXT/MD）"""
    pattern = os.path.join(root_dir, "**", "*")
    all_paths = glob.glob(pattern, recursive=True)
    files = []
    for p in all_paths:
        if os.path.isfile(p):
            ext = os.path.splitext(p)[1].lower()
            if ext in ALLOWED_EXTS:
                files.append(os.path.abspath(p))
    return files


def ensure_dirs(paper_folder):
    """确保论文目录和索引目录存在"""
    os.makedirs(paper_folder, exist_ok=True)
    os.makedirs(INDEX_FOLDER, exist_ok=True)


def make_embed_model(keep_alive="0s"):
    """创建嵌入模型实例（用完即停，减少内存占用）"""
    return OllamaEmbedding(
        model_name=EMBED_MODEL,
        base_url=OLLAMA_BASE_URL,
        additional_kwargs={"keep_alive": keep_alive},
        request_timeout=600.0,
    )


def make_llm():
    """创建LLM实例（显式控制资源占用，保留多语言回答策略）"""
    return Ollama(
        model=LLM_MODEL,
        base_url=OLLAMA_BASE_URL,
        request_timeout=600.0,
        temperature=0.2,  # 低温度保证回答稳定
        system_prompt=(
            "你是一个研究助理。请务必每次使用问你问题的语种回答我，"
            "比如使用中文问你，你就中文回答我；使用英语问你，你就英语回答我。"
        ),
        additional_kwargs={
            "num_ctx": NUM_CTX,
            "num_gpu": NUM_GPU,
            "keep_alive": LLM_KEEP_ALIVE,
        },
    )


def stop_model(model_name: str):
    """主动停止指定Ollama模型，释放内存"""
    if ollama_stop is not None:
        try:
            ollama_stop(model_name)
        except Exception:
            # 忽略停止失败（模型可能已停止）
            pass


def stop_embed_model():
    """停止嵌入模型"""
    stop_model(EMBED_MODEL)


def stop_llm_model():
    """停止LLM模型"""
    stop_model(LLM_MODEL)


# ===================== 索引构建/加载 =====================
def build_or_load_index(paper_folder) -> VectorStoreIndex:
    """加载已有索引或构建新索引，同时记录语料标题供路由参考"""
    has_existing = os.path.isdir(INDEX_FOLDER) and bool(os.listdir(INDEX_FOLDER))
    files = find_files(paper_folder)
    
    # 记录语料标题（最多100个，避免Prompt过长）
    global CORPUS_TITLES
    CORPUS_TITLES = [os.path.basename(f) for f in files][:100]

    # 尝试加载已有索引
    if has_existing:
        try:
            print("检测到已存在索引，正在加载...")
            storage_context = StorageContext.from_defaults(persist_dir=INDEX_FOLDER)
            index = load_index_from_storage(storage_context)
            return index
        except Exception as e:
            print(f"加载索引失败，将重建。错误信息: {e}")

    # 构建新索引
    if not files:
        raise RuntimeError(
            f"未在目录 {paper_folder} 中找到可解析文件。请放入至少一个 {', '.join(sorted(ALLOWED_EXTS))} 文件。"
        )

    print(f"正在从 {paper_folder} 构建索引，共 {len(files)} 个文件...")
    embed_model = make_embed_model(keep_alive="0s")
    Settings.embed_model = embed_model
    Settings.llm = None  # 索引阶段不加载LLM，节省内存

    docs = SimpleDirectoryReader(input_files=files).load_data()
    index = VectorStoreIndex.from_documents(docs, embed_model=embed_model)
    index.storage_context.persist(persist_dir=INDEX_FOLDER)
    print(f"索引已构建并保存到: {INDEX_FOLDER}")

    # 索引构建完成后停止嵌入模型
    stop_embed_model()
    return index


# ===================== 路由与回答 =====================
def llm_route_decide(llm, query: str) -> str:
    """由LLM纯语义决策路由：RAG（基于文档）/FREE（自由回答）"""
    # 拼接语料标题（最多50个，控制Prompt长度）
    titles_str = "\n".join(f"- {t}" for t in CORPUS_TITLES[:50]) if CORPUS_TITLES else "（无语料文件）"
    
    prompt = (
        "你是一个路由器。根据用户问题是否明确涉及到我文件夹中的文档，决定走哪条路径。\n"
        "规则：\n"
        "1) 如果问题是关于这些文档本身（如'这篇/这两篇/上述/报告/论文/文档/附件/实验/结果/方法/对比/引用/来源/细节'等）"
        "或明显要基于这些文档的内容来回答，请输出：RAG\n"
        "2) 否则（常识性、背景知识、与语料主题无关等），请输出：FREE\n"
        "只输出一个词：RAG 或 FREE，不要输出其他内容。\n\n"
        f"文档清单（部分）：\n{titles_str}\n\n"
        f"用户问题：{query}\n"
        "你的输出（只能是 RAG 或 FREE）："
    )

    try:
        completion = llm.complete(prompt)
        out = completion.text.strip().upper() if hasattr(completion, "text") else str(completion).strip().upper()
    except Exception:
        # 异常时默认FREE，避免误触发RAG
        out = "FREE"

    # 严格判定输出结果
    if "RAG" in out and "FREE" not in out:
        return "RAG"
    if "FREE" in out and "RAG" not in out:
        return "FREE"
    return "FREE"


def retrieve_then_answer(index: VectorStoreIndex, query: str, top_k: int = 6, response_mode: str = "compact"):
    """路由决策 → 检索/回答一体化逻辑"""
    # 第一步：LLM语义路由决策
    llm_router = make_llm()
    route = llm_route_decide(llm_router, query)
    print(f"[Router] LLM 决策结果 -> {route}")

    if route == "RAG":
        # RAG模式：基于文档回答（先停路由LLM，避免内存叠加）
        if NO_OVERLAP:
            stop_llm_model()

        # 检索相关文档
        embed_model = make_embed_model(keep_alive="0s")
        Settings.embed_model = embed_model
        retriever = index.as_retriever(similarity_top_k=top_k)
        
        try:
            nodes = retriever.retrieve(query)
        finally:
            # 检索完成立即停止嵌入模型
            stop_embed_model()

        # 使用严格QA模板生成回答
        llm_strict = make_llm()
        Settings.llm = llm_strict
        synthesizer = get_response_synthesizer(
            response_mode=response_mode,
            llm=llm_strict,
            text_qa_template=STRICT_QA_TEMPLATE,  # 绑定严格回答模板
        )
        response = synthesizer.synthesize(query, nodes)
        return response, nodes

    else:
        # FREE模式：纯LLM自由回答（不依赖文档）
        llm_free = make_llm()
        Settings.llm = llm_free
        completion = llm_free.complete(query)
        text = completion.text if hasattr(completion, "text") else str(completion)
        return text, []


# ===================== 交互式查询 =====================
def interactive_query(index: VectorStoreIndex):
    """交互式问答主逻辑"""
    print("\n=== 索引就绪，开始交互 ===")
    print("示例问题：")
    print("- 总结这些论文的核心方法")
    print("- 它们的共同局限是什么？")
    print("- 有哪些尚未探索的组合思路？")
    print("输入 'exit' 退出问答\n")

    while True:
        try:
            query = input("请输入你的研究问题： ").strip()
        except EOFError:
            # 处理Ctrl+D等EOF输入
            break
        
        if query.lower() == "exit":
            break
        if not query:
            # 忽略空输入
            continue

        # 执行查询并处理异常
        try:
            response, nodes = retrieve_then_answer(index, query, top_k=6, response_mode="compact")
        except Exception as e:
            print(f"\n❌ 查询失败：{e}\n")
            continue

        # 打印回答结果（兼容不同响应格式）
        print("\n--- AI 回复 ---")
        if hasattr(response, "response") and isinstance(response.response, str):
            print(response.response)
        elif hasattr(response, "text") and isinstance(response.text, str):
            print(response.text)
        else:
            print(str(response))

        # 打印参考来源（仅RAG模式）
        try:
            source_nodes = getattr(response, "source_nodes", None) or nodes
            if source_nodes:
                print("\n--- 参考来源 ---")
                for sn in source_nodes:
                    node = getattr(sn, "node", None)
                    file_path = ""
                    if node and hasattr(node, "metadata"):
                        file_path = node.metadata.get("file_path", "") or node.metadata.get("filename", "")
                    score = getattr(sn, "score", None)
                    if score is not None:
                        print(f"- {file_path} (相似度={score:.3f})")
                    else:
                        print(f"- {file_path}")
        except Exception:
            # 忽略来源打印失败的情况
            pass
        print("-" * 50)

    print("\n已退出交互式问答。")


# ===================== 命令行参数解析 & 主函数 =====================
def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="基于Ollama+LlamaIndex的论文RAG查询工具（LLM语义路由版）")
    parser.add_argument("--papers", type=str, default=DEFAULT_PAPER_FOLDER, help="论文目录路径（默认：./papers）")
    parser.add_argument("--index", type=str, default=INDEX_FOLDER, help="索引持久化目录（默认：./index）")
    parser.add_argument("--base-url", type=str, default=OLLAMA_BASE_URL, help="Ollama服务地址（默认：http://localhost:11434）")
    parser.add_argument("--llm", type=str, default=LLM_MODEL, help="LLM模型名称（默认：gemma3:27b-it-qat）")
    parser.add_argument("--embed", type=str, default=EMBED_MODEL, help="嵌入模型名称（默认：nomic-embed-text）")
    parser.add_argument("--num-ctx", type=int, default=NUM_CTX, help="LLM上下文长度（默认：4096，降低可省内存）")
    parser.add_argument("--num-gpu", type=int, default=NUM_GPU, help="显存占用层数（默认：999=自动最大化）")
    parser.add_argument("--llm-keep-alive", type=str, default=LLM_KEEP_ALIVE, help="LLM保活时长（默认：10m，0s=用完即停）")
    parser.add_argument("--no-overlap", action="store_true", help="检索前停止LLM，避免内存叠加占用")
    return parser.parse_args()


def main():
    """程序主入口"""
    # 解析命令行参数并覆盖全局配置
    args = parse_args()
    global INDEX_FOLDER, OLLAMA_BASE_URL, LLM_MODEL, EMBED_MODEL, NUM_CTX, NUM_GPU, LLM_KEEP_ALIVE, NO_OVERLAP
    INDEX_FOLDER = args.index
    OLLAMA_BASE_URL = args.base_url
    LLM_MODEL = args.llm
    EMBED_MODEL = args.embed
    NUM_CTX = args.num_ctx
    NUM_GPU = args.num_gpu
    LLM_KEEP_ALIVE = args.llm_keep_alive
    NO_OVERLAP = True if args.no_overlap else NO_OVERLAP

    # 打印运行配置
    print("=== 运行配置 ===")
    print(f"当前工作目录：{os.getcwd()}")
    print(f"论文目录：{args.papers} | 索引目录：{INDEX_FOLDER}")
    print(f"Ollama地址：{OLLAMA_BASE_URL}")
    print(f"模型配置：LLM={LLM_MODEL} | Embedding={EMBED_MODEL}")
    print(f"资源配置：num_ctx={NUM_CTX} | num_gpu={NUM_GPU} | llm_keep_alive={LLM_KEEP_ALIVE} | no_overlap={NO_OVERLAP}")
    print("=" * 50)

    # 主流程：初始化目录 → 构建/加载索引 → 交互式查询
    try:
        ensure_dirs(args.papers)
        index = build_or_load_index(args.papers)
        interactive_query(index)
    except Exception as e:
        print(f"\n❌ 程序异常退出：{e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
    