import os
import sys
import glob
import argparse
import math

from llama_index.core import (
    VectorStoreIndex,
    SimpleDirectoryReader,
    StorageContext,
    load_index_from_storage,
    Settings,
)
from llama_index.llms.ollama import Ollama
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.core.response_synthesizers import get_response_synthesizer

try:
    from ollama import stop as ollama_stop
except Exception:
    ollama_stop = None

# 默认配置
DEFAULT_PAPER_FOLDER = "./papers"
INDEX_FOLDER = "./index"
OLLAMA_BASE_URL = "http://localhost:11434"

# 模型名称
LLM_MODEL = "gemma3:27b-it-qat"
EMBED_MODEL = "nomic-embed-text"

ALLOWED_EXTS = {".pdf", ".txt", ".md"}

# 运行选项（可被命令行覆盖）
NUM_CTX = 4096  # 降低 KV cache 占用
NUM_GPU = 999   # 尽量把层放进显存
LLM_KEEP_ALIVE = "10m"  # 交互期内保活；避免频繁重载
NO_OVERLAP = True  # 每轮问答前先停掉 LLM，再做检索，避免“LLM+Embedding”叠加占用

# 方案 C：规则 + 灰区 LLM 二分类
ROUTE_T_LOW = 0.62       # 低阈值：明显不相关则走自由回答
ROUTE_T_HIGH = 0.70      # 高阈值：明显相关则走 RAG
GAP_MIN = 0.03           # top - mean 的最小差值，防“整体抬高”
PROFILE_T = 0.45         # 语料轮廓相似度阈值（主题相关性）
COVERAGE_BAND = 0.02     # 覆盖率带宽：分数扎堆时认为不稳
COVERAGE_MAX_NEAR = 3    # 前 k 中接近阈值的条目数达到该值，判为不稳（倾向 FREE）

# 全局：语料轮廓嵌入（初始化为空）
CORPUS_PROFILE_TEXT = ""
CORPUS_PROFILE_EMB = None


def find_files(root_dir):
    """递归查找指定目录下的合法文件"""
    pattern = os.path.join(root_dir, "**", "*")
    all_paths = glob.glob(pattern, recursive=True)
    files = []
    for p in all_paths:
        if os.path.isfile(p):
            ext = os.path.splitext(p)[1].lower()
            if ext in ALLOWED_EXTS:
                files.append(os.path.abspath(p))
    return files


def ensure_dirs(paper_folder):
    """确保论文目录和索引目录存在"""
    os.makedirs(paper_folder, exist_ok=True)
    os.makedirs(INDEX_FOLDER, exist_ok=True)


def make_embed_model(keep_alive="0s"):
    """创建嵌入模型实例（用完即停，减少内存占用）"""
    # keep_alive=0s -> 嵌入模型不常驻，调用完成后退出，避免与 LLM 同时占用
    return OllamaEmbedding(
        model_name=EMBED_MODEL,
        base_url=OLLAMA_BASE_URL,
        additional_kwargs={
            "keep_alive": keep_alive,
        },
        request_timeout=600.0,
    )


def make_llm():
    """创建LLM实例（显式控制资源占用）"""
    # 显式控制 num_ctx/num_gpu，降低系统内存消耗
    # 保持你的中文策略不变
    return Ollama(
        model=LLM_MODEL,
        base_url=OLLAMA_BASE_URL,
        request_timeout=600.0,
        temperature=0.2,
        system_prompt="你是一个研究助理。请务必每次使用问你问题的语种回答我，比如使用中文问你，你就中文回答我；使用英语问你，你就英语回答我。",
        additional_kwargs={
            "num_ctx": NUM_CTX,
            "num_gpu": NUM_GPU,
            "keep_alive": LLM_KEEP_ALIVE,
        },
    )


def stop_model(model_name: str):
    """主动停止指定Ollama模型，释放内存"""
    if ollama_stop is not None:
        try:
            ollama_stop(model_name)
        except Exception:
            # 忽略停止失败的情况（模型可能已停止）
            pass


def stop_embed_model():
    """停止嵌入模型"""
    stop_model(EMBED_MODEL)


def stop_llm_model():
    """停止LLM模型"""
    stop_model(LLM_MODEL)


def cosine_sim(a, b):
    """计算两个向量的余弦相似度"""
    if not a or not b or len(a) != len(b):
        return 0.0
    dot_product = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot_product / (norm_a * norm_b)


def build_corpus_profile(files, embed_model):
    """构建语料轮廓（基于文件名）并生成嵌入向量"""
    global CORPUS_PROFILE_TEXT, CORPUS_PROFILE_EMB
    if not files:
        return
    
    # 用文件名构建语料轮廓文本（轻量，避免加载全文）
    names = [os.path.splitext(os.path.basename(f))[0] for f in files]
    CORPUS_PROFILE_TEXT = " ".join(names)
    
    # 生成轮廓嵌入向量
    try:
        CORPUS_PROFILE_EMB = embed_model.get_text_embedding(CORPUS_PROFILE_TEXT)
    except Exception as e:
        print(f"构建语料轮廓嵌入失败：{e}")
        CORPUS_PROFILE_EMB = None


def build_or_load_index(paper_folder) -> VectorStoreIndex:
    """加载已有索引或构建新索引（含语料轮廓构建）"""
    has_existing = os.path.isdir(INDEX_FOLDER) and bool(os.listdir(INDEX_FOLDER))
    files = find_files(paper_folder)
    
    # 尝试加载已有索引
    if has_existing:
        try:
            print("检测到已存在索引，正在加载...")
            storage_context = StorageContext.from_defaults(persist_dir=INDEX_FOLDER)
            index = load_index_from_storage(storage_context)
            
            # 构建语料轮廓向量（一次嵌入）
            embed_model = make_embed_model(keep_alive="0s")
            build_corpus_profile(files, embed_model)
            stop_embed_model()
            return index
        except Exception as e:
            print(f"加载索引失败，将重建。错误信息: {e}")

    # 构建新索引逻辑
    if not files:
        raise RuntimeError(
            f"未在目录 {paper_folder} 中找到可解析文件。请放入至少一个 {', '.join(sorted(ALLOWED_EXTS))} 文件。"
        )

    print(f"正在从 {paper_folder} 构建索引，共 {len(files)} 个文件...")
    embed_model = make_embed_model(keep_alive="0s")
    Settings.embed_model = embed_model
    Settings.llm = None  # 索引阶段不加载 LLM，节省内存

    docs = SimpleDirectoryReader(input_files=files).load_data()
    index = VectorStoreIndex.from_documents(docs, embed_model=embed_model)
    index.storage_context.persist(persist_dir=INDEX_FOLDER)
    print(f"索引已构建并保存到: {INDEX_FOLDER}")

    # 构建语料轮廓向量
    build_corpus_profile(files, embed_model)

    # 索引构建完成后立即停止嵌入模型
    stop_embed_model()

    return index


def llm_gray_classify(llm, query, nodes):
    """灰区由LLM轻量判定：仅输出 RAG 或 FREE"""
    # 提取前3个检索结果的文件名（最少线索，控制token消耗）
    top_files = []
    for sn in nodes[:3]:
        node = getattr(sn, "node", None)
        if node and hasattr(node, "metadata"):
            fp = node.metadata.get("file_path", "") or node.metadata.get("filename", "")
            if fp:
                top_files.append(os.path.basename(fp))
    
    files_str = ", ".join(top_files) if top_files else "（无文件名）"
    prompt = (
        "请只输出一个词用于路由决策：\n"
        "如果这个问题与我检索到的文档主题密切相关、适合基于文档回答，请输出：RAG\n"
        "如果不相关或更适合常识性回答，请输出：FREE\n"
        f"检索到的文件：{files_str}\n"
        f"用户问题：{query}\n"
        "只输出 RAG 或 FREE，不要输出其他内容。"
    )
    
    try:
        completion = llm.complete(prompt)
        out = completion.text.strip().upper() if hasattr(completion, "text") else str(completion).strip().upper()
    except Exception:
        # 异常时默认FREE，避免误引文档
        out = "FREE"
    
    # 严格判定输出结果
    if "RAG" in out and "FREE" not in out:
        return "RAG"
    if "FREE" in out and "RAG" not in out:
        return "FREE"
    # 模糊时默认 FREE，避免误引文档
    return "FREE"


def retrieve_then_answer(index: VectorStoreIndex, query: str, top_k: int = 6, response_mode: str = "compact"):
    """检索+路由+回答一体化逻辑"""
    # 为避免“嵌入 + LLM”叠加占用，先停 LLM
    if NO_OVERLAP:
        stop_llm_model()

    # Step 1: 检索与主题相关性计算（一次嵌入会话内完成）
    embed_model = make_embed_model(keep_alive="0s")
    Settings.embed_model = embed_model
    retriever = index.as_retriever(similarity_top_k=top_k)

    nodes = []
    q_emb = None
    try:
        nodes = retriever.retrieve(query)
        # 计算 query 与语料轮廓的相似度
        try:
            q_emb = embed_model.get_text_embedding(query)
        except Exception as e:
            print(f"生成查询嵌入失败：{e}")
            q_emb = None
    finally:
        # 无论检索成功与否，都停止嵌入模型
        stop_embed_model()

    # 打分统计（过滤无效分数）
    scores = [getattr(sn, "score", None) for sn in nodes if getattr(sn, "score", None) is not None]
    top_score = max(scores) if scores else 0.0
    mean_score = sum(scores) / len(scores) if scores else 0.0
    gap = top_score - mean_score

    # 语料轮廓相似度计算
    s_profile = 0.0
    if q_emb is not None and CORPUS_PROFILE_EMB is not None:
        s_profile = cosine_sim(q_emb, CORPUS_PROFILE_EMB)

    # 覆盖率判定：分数扎堆（接近低阈值）的条目数
    coverage_near = sum(1 for s in scores if ROUTE_T_LOW - COVERAGE_BAND <= s <= ROUTE_T_LOW + COVERAGE_BAND)

    # 规则路由判定
    route_by_rule = None
    # 规则 1：明显不相关（主题或分数）
    if s_profile < PROFILE_T or top_score < ROUTE_T_LOW:
        route_by_rule = "FREE"
    # 规则 2：明显相关（高分且差值足够）
    elif top_score >= ROUTE_T_HIGH and gap >= GAP_MIN:
        route_by_rule = "RAG"
    # 规则 3：分数扎堆不稳，倾向 FREE
    elif coverage_near >= COVERAGE_MAX_NEAR:
        route_by_rule = "FREE"

    print(f"[Router] top={top_score:.3f}, mean={mean_score:.3f}, gap={gap:.3f}, s_profile={s_profile:.3f}, cov_near={coverage_near} -> {'RULE:'+route_by_rule if route_by_rule else 'GRAY'}")

    # Step 2：回答（若灰区则用 LLM 二分类）
    llm = make_llm()
    Settings.llm = llm

    final_route = route_by_rule
    route_source = "rule"
    if final_route is None:
        # 灰区：由LLM判定
        final_route = llm_gray_classify(llm, query, nodes)
        route_source = "llm"
    print(f"[Router] final -> {final_route.upper()} ({route_source})")

    # 根据最终路由策略生成回答
    if final_route == "RAG" and nodes:
        # RAG模式：基于检索文档回答
        synthesizer = get_response_synthesizer(response_mode=response_mode, llm=llm)
        response = synthesizer.synthesize(query, nodes)
        return response, nodes
    else:
        # FREE模式：纯LLM常识回答
        completion = llm.complete(query)
        text = completion.text if hasattr(completion, "text") else str(completion)
        return text, []


def interactive_query(index: VectorStoreIndex):
    """交互式查询主逻辑"""
    print("\n索引就绪。示例问题：")
    print("- 总结这些论文的核心方法")
    print("- 它们的共同局限是什么？")
    print("- 有哪些尚未探索的组合思路？")

    while True:
        try:
            query = input("\n请输入你的研究问题（输入 'exit' 退出）： ").strip()
        except EOFError:
            # 处理Ctrl+D等EOF输入
            break
        if query.lower() == "exit":
            break
        if not query:
            # 忽略空输入
            continue

        try:
            response, nodes = retrieve_then_answer(index, query, top_k=6, response_mode="compact")
        except Exception as e:
            print(f"查询失败：{e}")
            continue

        # 打印回答结果（兼容不同响应格式）
        print("\n--- AI 回复 ---")
        if hasattr(response, "response") and isinstance(response.response, str):
            print(response.response)
        elif hasattr(response, "text") and isinstance(response.text, str):
            print(response.text)
        else:
            print(str(response))

        # 打印参考来源（若有）
        try:
            source_nodes = getattr(response, "source_nodes", None) or nodes
            if source_nodes:
                print("\n--- 参考来源 ---")
                for sn in source_nodes:
                    node = getattr(sn, "node", None)
                    file_path = ""
                    if node and hasattr(node, "metadata"):
                        file_path = node.metadata.get("file_path", "") or node.metadata.get("filename", "")
                    score = getattr(sn, "score", None)
                    if score is not None:
                        print(f"- {file_path} (score={score:.3f})")
                    else:
                        print(f"- {file_path}")
        except Exception:
            # 忽略来源打印失败的情况
            pass

    print("\n已退出。")


def parse_args():
    """解析命令行参数"""
    ap = argparse.ArgumentParser(description="基于Ollama+LlamaIndex的论文RAG查询工具（规则+LLM二分类路由）")
    ap.add_argument("--papers", type=str, default=DEFAULT_PAPER_FOLDER, help="论文目录路径")
    ap.add_argument("--index", type=str, default=INDEX_FOLDER, help="索引持久化目录")
    ap.add_argument("--base-url", type=str, default=OLLAMA_BASE_URL, help="Ollama 服务地址")
    ap.add_argument("--llm", type=str, default=LLM_MODEL, help="LLM 模型名称")
    ap.add_argument("--embed", type=str, default=EMBED_MODEL, help="嵌入模型名称")
    ap.add_argument("--num-ctx", type=int, default=NUM_CTX, help="LLM 上下文长度（降低可省系统内存）")
    ap.add_argument("--num-gpu", type=int, default=NUM_GPU, help="尽量放进显存的层数（999=自动尽量多）")
    ap.add_argument("--llm-keep-alive", type=str, default=LLM_KEEP_ALIVE, help="LLM 保活时长，例：'10m'、'0s'")
    ap.add_argument("--no-overlap", action="store_true", help="检索前强制停止 LLM，避免与嵌入模型同时占用")
    return ap.parse_args()


def main():
    """主函数"""
    args = parse_args()
    
    # 覆盖全局配置
    global INDEX_FOLDER, OLLAMA_BASE_URL, LLM_MODEL, EMBED_MODEL, NUM_CTX, NUM_GPU, LLM_KEEP_ALIVE, NO_OVERLAP
    INDEX_FOLDER = args.index
    OLLAMA_BASE_URL = args.base_url
    LLM_MODEL = args.llm
    EMBED_MODEL = args.embed
    NUM_CTX = args.num_ctx
    NUM_GPU = args.num_gpu
    LLM_KEEP_ALIVE = args.llm_keep_alive
    NO_OVERLAP = True if args.no_overlap else NO_OVERLAP

    # 打印运行配置
    print(f"当前工作目录：{os.getcwd()}")
    print(f"论文目录：{args.papers}")
    print(f"Ollama 地址：{OLLAMA_BASE_URL}")
    print(f"LLM：{LLM_MODEL} | Embedding：{EMBED_MODEL}")
    print(f"运行选项：num_ctx={NUM_CTX}, num_gpu={NUM_GPU}, llm_keep_alive={LLM_KEEP_ALIVE}, no_overlap={NO_OVERLAP}")

    try:
        # 确保目录存在
        ensure_dirs(args.papers)
        # 构建/加载索引
        index = build_or_load_index(args.papers)
        # 进入交互式查询
        interactive_query(index)
    except Exception as e:
        print(f"程序错误：{e}")
        # 异常时优雅退出，避免强制崩溃
        sys.exit(1)


if __name__ == "__main__":
    main()