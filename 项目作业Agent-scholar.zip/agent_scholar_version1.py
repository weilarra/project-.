import os
import sys
import glob
import argparse

from llama_index.core import (
    VectorStoreIndex,
    SimpleDirectoryReader,
    StorageContext,
    load_index_from_storage,
    Settings,
)
from llama_index.llms.ollama import Ollama
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.core.response_synthesizers import get_response_synthesizer

try:
    from ollama import stop as ollama_stop
except Exception:
    ollama_stop = None

# 默认配置
DEFAULT_PAPER_FOLDER = "./papers"
INDEX_FOLDER = "./index"
OLLAMA_BASE_URL = "http://localhost:11434"

# 模型名称
LLM_MODEL = "gemma3:27b-it-qat"
EMBED_MODEL = "nomic-embed-text"

ALLOWED_EXTS = {".pdf", ".txt", ".md"}

# 运行选项（可被命令行覆盖）
NUM_CTX = 4096  # 降低 KV cache 占用
NUM_GPU = 999   # 尽量把层放进显存
LLM_KEEP_ALIVE = "10m"  # 交互期内保活；避免频繁重载
NO_OVERLAP = True  # 每轮问答前先停掉 LLM，再做检索，避免“LLM+Embedding”叠加占用


def find_files(root_dir):
    pattern = os.path.join(root_dir, "**", "*")
    all_paths = glob.glob(pattern, recursive=True)
    files = []
    for p in all_paths:
        if os.path.isfile(p):
            ext = os.path.splitext(p)[1].lower()
            if ext in ALLOWED_EXTS:
                files.append(os.path.abspath(p))
    return files


def ensure_dirs(paper_folder):
    os.makedirs(paper_folder, exist_ok=True)
    os.makedirs(INDEX_FOLDER, exist_ok=True)


def make_embed_model(keep_alive="0s"):
    # keep_alive=0s -> 嵌入模型不常驻，调用完成后退出，避免与 LLM 同时占用
    return OllamaEmbedding(
        model_name=EMBED_MODEL,
        base_url=OLLAMA_BASE_URL,
        # LlamaIndex 的 OllamaEmbedding 会把 additional_kwargs 透传给 /embeddings
        additional_kwargs={
            "keep_alive": keep_alive,
            # embeddings 不需要 num_ctx/num_gpu，这里不传
        },
        request_timeout=600.0,
    )


def make_llm():
    # 显式控制 num_ctx/num_gpu，降低系统内存消耗
    return Ollama(
        model=LLM_MODEL,
        base_url=OLLAMA_BASE_URL,
        request_timeout=600.0,
        temperature=0.2,
        sp = "你是一个研究助理。请务必每次使用问你问题的语种回答我，比如使用中文问你，你就中文回答我；使用英语问你，你就英语回答我。",
        additional_kwargs={
            "num_ctx": NUM_CTX,
            "num_gpu": NUM_GPU,
            "keep_alive": LLM_KEEP_ALIVE,
        },
    )


def stop_model(model_name: str):
    if ollama_stop is not None:
        try:
            ollama_stop(model_name)
        except Exception:
            pass


def stop_embed_model():
    stop_model(EMBED_MODEL)


def stop_llm_model():
    stop_model(LLM_MODEL)


def build_or_load_index(paper_folder) -> VectorStoreIndex:
    has_existing = os.path.isdir(INDEX_FOLDER) and bool(os.listdir(INDEX_FOLDER))
    if has_existing:
        try:
            print("检测到已存在索引，正在加载...")
            storage_context = StorageContext.from_defaults(persist_dir=INDEX_FOLDER)
            index = load_index_from_storage(storage_context)
            return index
        except Exception as e:
            print(f"加载索引失败，将重建。错误信息: {e}")

    # 构建索引逻辑
    files = find_files(paper_folder)
    if not files:
        raise RuntimeError(
            f"未在目录 {paper_folder} 中找到可解析文件。请放入至少一个 {', '.join(sorted(ALLOWED_EXTS))} 文件。"
        )

    print(f"正在从 {paper_folder} 构建索引，共 {len(files)} 个文件...")
    embed_model = make_embed_model(keep_alive="0s")
    Settings.embed_model = embed_model
    Settings.llm = None  # 索引阶段不加载 LLM

    docs = SimpleDirectoryReader(input_files=files).load_data()
    index = VectorStoreIndex.from_documents(docs, embed_model=embed_model)
    index.storage_context.persist(persist_dir=INDEX_FOLDER)
    print(f"索引已构建并保存到: {INDEX_FOLDER}")

    # 索引构建完成后立即停止嵌入模型
    stop_embed_model()

    return index


def retrieve_then_answer(index: VectorStoreIndex, query: str, top_k: int = 6, response_mode: str = "compact"):
    # 为避免“嵌入 + LLM”叠加占用，按需先停掉 LLM
    if NO_OVERLAP:
        stop_llm_model()

    # 第一步：检索（需要嵌入模型）——完成后立即停止嵌入模型
    embed_model = make_embed_model(keep_alive="0s")
    Settings.embed_model = embed_model
    retriever = index.as_retriever(similarity_top_k=top_k)

    try:
        nodes = retriever.retrieve(query)
    finally:
        stop_embed_model()

    # 第二步：回答（只用 LLM）
    llm = make_llm()
    Settings.llm = llm
    synthesizer = get_response_synthesizer(response_mode=response_mode, llm=llm)
    response = synthesizer.synthesize(query, nodes)

    return response, nodes


def interactive_query(index: VectorStoreIndex):
    print("\n索引就绪。示例问题：")
    print("- 总结这些论文的核心方法")
    print("- 它们的共同局限是什么？")
    print("- 有哪些尚未探索的组合思路？")

    while True:
        try:
            query = input("\n请输入你的研究问题（输入 'exit' 退出）： ").strip()
        except EOFError:
            break
        if query.lower() == "exit":
            break
        if not query:
            continue

        try:
            response, nodes = retrieve_then_answer(index, query, top_k=6, response_mode="compact")
        except Exception as e:
            print(f"查询失败：{e}")
            continue

        print("\n--- AI 回复 ---")
        if hasattr(response, "response") and isinstance(response.response, str):
            print(response.response)
        elif hasattr(response, "text") and isinstance(response.text, str):
            print(response.text)
        else:
            print(str(response))

        try:
            source_nodes = getattr(response, "source_nodes", None) or nodes
            if source_nodes:
                print("\n--- 参考来源 ---")
                for sn in source_nodes:
                    node = getattr(sn, "node", None)
                    file_path = ""
                    if node and hasattr(node, "metadata"):
                        file_path = node.metadata.get("file_path", "") or node.metadata.get("filename", "")
                    score = getattr(sn, "score", None)
                    if score is not None:
                        print(f"- {file_path} (score={score:.3f})")
                    else:
                        print(f"- {file_path}")
        except Exception:
            pass

    print("\n已退出。")


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--papers", type=str, default=DEFAULT_PAPER_FOLDER, help="论文目录路径")
    ap.add_argument("--index", type=str, default=INDEX_FOLDER, help="索引持久化目录")
    ap.add_argument("--base-url", type=str, default=OLLAMA_BASE_URL, help="Ollama 服务地址")
    ap.add_argument("--llm", type=str, default=LLM_MODEL, help="LLM 模型名称")
    ap.add_argument("--embed", type=str, default=EMBED_MODEL, help="嵌入模型名称")
    ap.add_argument("--num-ctx", type=int, default=NUM_CTX, help="LLM 上下文长度（降低可省系统内存）")
    ap.add_argument("--num-gpu", type=int, default=NUM_GPU, help="尽量放进显存的层数（999=自动尽量多）")
    ap.add_argument("--llm-keep-alive", type=str, default=LLM_KEEP_ALIVE, help="LLM 保活时长，例：'10m'、'0s'")
    ap.add_argument("--no-overlap", action="store_true", help="检索前强制停止 LLM，避免与嵌入模型同时占用")
    return ap.parse_args()


def main():
    args = parse_args()
    global INDEX_FOLDER, OLLAMA_BASE_URL, LLM_MODEL, EMBED_MODEL, NUM_CTX, NUM_GPU, LLM_KEEP_ALIVE, NO_OVERLAP
    INDEX_FOLDER = args.index
    OLLAMA_BASE_URL = args.base_url
    LLM_MODEL = args.llm
    EMBED_MODEL = args.embed
    NUM_CTX = args.num_ctx
    NUM_GPU = args.num_gpu
    LLM_KEEP_ALIVE = args.llm_keep_alive
    NO_OVERLAP = True if args.no_overlap else NO_OVERLAP

    print(f"当前工作目录：{os.getcwd()}")
    print(f"论文目录：{args.papers}")
    print(f"Ollama 地址：{OLLAMA_BASE_URL}")
    print(f"LLM：{LLM_MODEL} | Embedding：{EMBED_MODEL}")
    print(f"运行选项：num_ctx={NUM_CTX}, num_gpu={NUM_GPU}, llm_keep_alive={LLM_KEEP_ALIVE}, no_overlap={NO_OVERLAP}")

    try:
        ensure_dirs(args.papers)
        index = build_or_load_index(args.papers)
        interactive_query(index)
    except Exception as e:
        print(f"程序错误：{e}")


if __name__ == "__main__":
    main()